# coding:utf-8
from utils import FileSize
MF = FileSize("36723678")
print(MF)
